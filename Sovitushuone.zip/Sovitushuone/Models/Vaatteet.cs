﻿namespace Sovitushuone.Models
{
    public class Vaatteet
    {
        // Vaatteetluokka TODO
        internal string id;
    }
}