﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Sovitushuone.Models
{
    public class BlobInfo
    {
        public BlobInfo(Stream content, string contentType)
        {
        }
    }
}
